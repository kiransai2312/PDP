public class Pdp1 {
    public static void main(String[] args) throws InterruptedException {
        
        int[] f = new int[1000000];
        for (int j = 0; j < f.length; j++) {
            f[j] = (int) (Math.random() * 100000);
        }

        
        int nThreads = Runtime.getRuntime().availableProcessors();

        
        int blockSize = f.length / nThreads;
        int remainder = f.length % nThreads;
Thread[] threads = new Thread[nThreads];
        CountThread[] tasks = new CountThread[nThreads];
        long startTime = System.currentTimeMillis();
         int start = 0;
        for (int i = 0; i < nThreads; i++) {
            
            int end = start + blockSize + (i < remainder ? 1 : 0);
            tasks[i] = new CountThread(f, start, end);
            threads[i] = new Thread(tasks[i]);
            threads[i].start();
            start = end;
        }

       
        int totalEven = 0;
        for (int i = 0; i < nThreads; i++) {
            threads[i].join();
            totalEven += tasks[i].getCount();
        }

       
        long endTime = System.currentTimeMillis();
        long elapsedMillis = endTime - startTime;

        System.out.println("Running Time = " + elapsedMillis + " millisecs (" + (elapsedMillis / 1000.0) + ")");
        System.out.println("Number of Threads = " + nThreads);
        System.out.println("Number of even values = " + totalEven);
    }
}


class CountThread implements Runnable {
    private final int[] arr;
    private final int start;
    private final int end;
    private int count;

    public CountThread(int[] arr, int start, int end) {
        this.arr = arr;
        this.start = start;
        this.end = end;
        this.count = 0;
    }

    public int getCount() {
        return count;
    }

    @Override
    public void run() {
        for (int i = start; i < end; i++) {
            if (arr[i] % 2 == 0) {
                count++;
            }
        }
    }
}
